/**
 * Classe cercle à la fin de la première séance
 * calcul du périmètre
 * calcul de l'aire
 * calcul du centre
 * gestion de la couleur
 * méthode toString
 * 
 */
 
import java.awt.Color;

public class Cercle extends Courbe{

	// Les attributs
	private APoint centre;
	private int rayon;
	
	/**
	 * Le constructeur
	 * @param le centre 
     * @param le rayon
	 */ 
	public Cercle(APoint c, int r){
		super();
		centre = new APoint(c.x,c.y);
		rayon = r;
	}

	/**
	 * Le constructeur
	 * @param le centre
     * @param le rayon
     * @param la couleur
	 */ 
	public Cercle(APoint c, int r,Color uneCouleur){
		super(uneCouleur);
		centre = new APoint(c.x,c.y);
		rayon = r;       
	}
	
	/** 
	 * Pour calculer le périmètre d'un cercle
	 * @return le périmètre
	 */
	public double longueur(){
		return 2.0*Math.PI*rayon;
	}
	
	/**
	 * Pour calculer l'aire d'un cercle
	 * @return l'aire
	 */ 
	public double aire(){
		return Math.PI*rayon*rayon;
	}
	
	/**
	 * Pour récupérer le centre d'un cercle
	 * @return le centre du cercle
	 */ 
	public APoint barycentre(){
		return centre;
	}
  

	/**
	 * Pour afficher les données du cercle
	 * @return le centre et le rayon
	 */
    public String toString(){
		String res = super.toString();
		res+=("Cercle de centre ("+centre.x+","+centre.y+") et de rayon "+rayon);
		return res;
	}
}


