/**
 * Classe Polygone à la fin de la première séance
 * calcul du périmètre
 * calcul de l'aire
 * calcul du centre
 * gestion de la couleur
 * méthode toString
 * 
 */
 
import java.awt.Color;

public class Polygone extends Courbe{
	
	// Les attributs	
	private APoint[] points;

	/**
	 * Le constructeur
	 * @param le tableau de points décrivant chaque sommet
	 */ 
	public Polygone(APoint[] p){
		super();
		points = new APoint[p.length];
		for(int i=0; i<p.length; i++)
			points[i] = new APoint(p[i].x,p[i].y);
	}
	
	/**
	 * Le constructeur
	 * @param le tableau de points décrivant chaque sommet et une couleur
	 * @param la couleur associée
	 */ 
	public Polygone(APoint[] p, Color uneCouleur){
		super(uneCouleur);
		points = new APoint[p.length];
		for(int i=0; i<p.length; i++)
			points[i] = new APoint(p[i].x,p[i].y);
	}
	
	/**
	 * Pour calculer le périmètre d'un polygone
	 * @return le périmètre
	 */ 
	public double longueur(){
		double resultat=0;
		for(int i=1; i<points.length; i++){
			resultat += points[i-1].distance(points[i]);
		}
		// ajout de la distance entre dernier et premier point
		resultat += points[points.length-1].distance(points[0]);
		return resultat;
	}
	
	/**
	 * Pour calculer l'aire d'un polygone
	 * @return l'aire
	 */ 
	public double aire(){
		double a=0;
		int i;
		for(i=0; i<points.length-1; i++)
			a += points[i].x*points[i+1].y - points[i+1].x*points[i].y;
		// "i" a la valeur points.length-1 maintenant
		a += points[i].x*points[0].y - points[0].x*points[i].y;
		return 0.5*a;
	}
	
	/**
	 * Pour calculer le barycentre d'un polygone
	 * @return le barycentre sous forme d'un APoint
	 */ 
	public APoint barycentre(){
		APoint resultat = new APoint(0,0);
		int i;
		for(i=0; i<points.length-1; i++){
			resultat.x += (points[i].x+points[i+1].x) * (points[i].x*points[i+1].y - points[i+1].x*points[i].y);
			resultat.y += (points[i].y+points[i+1].y) * (points[i].x*points[i+1].y - points[i+1].x*points[i].y);
		}
		// "i" a la valeur points.length-1 maintenant
		resultat.x += (points[i].x+points[0].x) * (points[i].x*points[0].y - points[0].x*points[i].y);
		resultat.y += (points[i].y+points[0].y) * (points[i].x*points[0].y - points[0].x*points[i].y);
		double a = aire();
		resultat.x /= 6*a;
		resultat.y /= 6*a;
		return resultat;
  }
  

	/**
	 * Pour afficher les données du polygone
	 * @return les coordonnées des sommets
	 */
	public String toString(){
		String res;
		res=super.toString();
		res += "Polygone avec "+ points.length+ " sommets : ";
		for(int i=0; i<points.length; i++)
			res += " (" + points[i].x + "," + points[i].y + ") ";
		return res;
	}

}

