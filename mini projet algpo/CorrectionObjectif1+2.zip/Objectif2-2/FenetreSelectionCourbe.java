/**
 * La fenêtre principale pour sélectionner les courbes à étudier
 * Placement des widgets
 * Interaction avec le bouton
 * Utilisation d'un JOptionPane
 * 
 */

// Chargement des bibliothèques Swing et AWT
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList; 

public class FenetreSelectionCourbe extends JFrame implements ActionListener {
	
	// Les Widgets à déclarer en dehors du constructeur
	private JTextField textChoix;
	private JTextField affResult;
	private JButton monBoutonAfficher;
    private JButton monBoutonEffacer;
	private LinkedList<Courbe> maListe;
		
	public FenetreSelectionCourbe(LinkedList<Courbe> maListeCourbe){
		maListe = maListeCourbe;
		this.setTitle("IHM Courbe - Selection ");
		this.setSize(400,400);
		// Pour placer la fenêtre au centre de l'écran
		//~ this.setLocationRelativeTo(null);
		this.setLocation(300,200);
		// Pour empêcher le redimensionnement de la fenêtre
		this.setResizable(false);
		// Pour permettre la fermeture de la fenêtre lors de l'appui sur la croix rouge
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	

		
		/**
		 * Mon panneau 1
		 */
		JPanel panneauChoix = new JPanel();
		panneauChoix.setBounds(20,20,360,150);
		panneauChoix.setLayout(null);
		panneauChoix.setBackground(Color.green);
		
		JLabel affChoix = new JLabel();
		affChoix.setText("Entrez 1 numéro de courbe (entre 1 et " + maListe.size() + ") \n");
		affChoix.setBounds(15,10,340,50);
		panneauChoix.add(affChoix);
		
		textChoix = new JTextField();
		textChoix.setBounds(150,70,60,50);
		panneauChoix.add(textChoix);
		
		/**
		 * Mon panneau 2
		 */
		JPanel panneauResult = new JPanel();
		panneauResult.setBounds(20,190,360,150);
		panneauResult.setLayout(null);
		panneauResult.setBackground(Color.blue);
		
		monBoutonAfficher = new JButton("Afficher");
		monBoutonAfficher.setBounds(10,10,160,50);
		monBoutonAfficher.setBackground(new Color(10,144,10));
		monBoutonAfficher.setForeground(Color.white);
		/* branchement de l'écouteur*/
		monBoutonAfficher.addActionListener(this);
		panneauResult.add(monBoutonAfficher);
		
		monBoutonEffacer = new JButton("Effacer");
		monBoutonEffacer.setBounds(190,10,160,50);
		monBoutonEffacer.setBackground(new Color(144,10,10));
		monBoutonEffacer.setForeground(Color.white);
		/* branchement de l'écouteur*/
		monBoutonEffacer.addActionListener(this);
		panneauResult.add(monBoutonEffacer);
		
		affResult = new JTextField();
		affResult.setBounds(15,70,330,50);
		panneauResult.add(affResult);
		

		
		/**
		 * Mon panneau Global
		 */
		JPanel panneauGlobal = new JPanel();
		panneauGlobal.setBounds(0,0,400,400);
		panneauGlobal.setLayout(null);
		panneauGlobal.setBackground(Color.yellow);
		panneauGlobal.add(panneauChoix);
		panneauGlobal.add(panneauResult);
		
		this.add(panneauGlobal);
		
		// Pour rendre la fenêtre visible
		this.setVisible(true);
		
	}
	
	/**
	 * Suite à un événement
	 * Il faut distinguer l'action selon la source
     * Gestion de la fenêtre modale
	 */
	public void actionPerformed (ActionEvent e){
		if (e.getSource()== monBoutonEffacer){
			System.out.println("Click sur Effacer !");
			affResult.setText("");
		}
        if (e.getSource()== monBoutonAfficher){
            System.out.println("Click sur Afficher !");
            int choix = Integer.parseInt(textChoix.getText());
		    if (choix>maListe.size() || choix<1){
                JOptionPane.showMessageDialog(this,"Veuillez rentrer un nombre entre 1 et "+maListe.size()+" !");
            } else{
                System.out.println(maListe.get(choix-1));
                // Pour rappel, la première case du tableau est 0
                affResult.setText(maListe.get(choix-1).toString());
            }
        }
	}
}
		

		
		

		
		
		
