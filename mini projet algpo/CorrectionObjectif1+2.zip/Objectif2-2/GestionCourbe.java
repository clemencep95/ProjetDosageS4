
/**
 * Classe principale pour gérer différents types de courbe et leur couleur
 * 
 * Permet de créer une fenêtre pour gérer la liste de courbes
 */ 
 
import java.awt.Color;
import java.util.LinkedList; 
 
public class GestionCourbe{
  
	public static void main(String[] args){
		
		// Création d'une liste de courbes
		LinkedList<Courbe> listeCourbe=new LinkedList<Courbe>();
		
		// création de 3 cercles
		Courbe c1 = new Cercle(new APoint(100,100), 50);
		Courbe c2 = new Cercle(new APoint(300,300), 80);
		Courbe c3 = new Cercle(new APoint(200,150), 30, Color.blue);
		
		// Création de 2 polygones
		APoint[] p1 = new APoint[4];
		p1[0] = new APoint(50, 200);
		p1[1] = new APoint(200, 200);
		p1[2] = new APoint(150, 300);
		p1[3] = new APoint(100, 300);
		Courbe poly1 = new Polygone(p1, Color.magenta);
		
		APoint[] p2 = new APoint[3];
		p2[0] = new APoint(250, 50);
		p2[1] = new APoint(350, 120);
		p2[2] = new APoint(260, 200);
		Courbe poly2 = new Polygone(p2, Color.pink);

		// Remplissage du tableau par les courbes créées auparavant
		listeCourbe.add(c1);
		listeCourbe.add(c2);
		listeCourbe.add(c3);
		listeCourbe.add(poly1);
		listeCourbe.add(poly2);
		
		// Création de la fenêtre pour l'IHM
		FenetreSelectionCourbe maFrameSelectionCourbe = new FenetreSelectionCourbe(listeCourbe);
   }
   
}

